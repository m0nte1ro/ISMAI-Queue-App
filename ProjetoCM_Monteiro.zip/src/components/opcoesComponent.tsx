import {IonCard, IonRow} from '@ionic/react';
import { Opcao } from '../pages/HomePage';

interface OpcaoProp{
    propOpcao: Opcao;
}

const OpcaoComponent: React.FC<OpcaoProp> = ({ propOpcao }) =>{
    return(
        <IonCard className="opcoesCards" onClick={()=>window.location.href="/senha/"+propOpcao.id}>
            <IonRow><h1>{propOpcao.descricao}</h1></IonRow>
            <IonRow><p>Balcão: {propOpcao.balcao} - Senha: {propOpcao.letra}</p></IonRow>
        </IonCard>
    );
}

export default OpcaoComponent;