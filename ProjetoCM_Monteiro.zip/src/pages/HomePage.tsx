import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, useIonViewDidEnter, useIonAlert, IonItem, IonRow, useIonViewWillEnter  } from '@ionic/react';
import axios from 'axios';
import React, {useState, useEffect} from 'react';
import OpcaoComponent from '../components/opcoesComponent';
import './Styles.css';

export interface Opcao {
  balcao: string;
  descricao: string;
  id: string;
  letra: string;
}

const HomePage: React.FC = () => {
  
  const [listaOpcoes2, setListOpcoes2] = useState<Opcao[]>([])
  const API_URL = 'https://ismai-ticket-system.herokuapp.com/';
  const [alerta] = useIonAlert();

  useIonViewWillEnter(()=>{ //Sistema de verificação muito fácil de enganar mas serve para enganar 99% das pessoas
    if(localStorage.getItem("user-token")==null){ //Se não tiver cookie ele nem tentar fazer mais nada
      window.location.href="/login";
    }else{
        axios({
          method:"POST",
          url: API_URL+'/verificar_token',
          headers:{},
          data:{
            token: localStorage.getItem("user-token")
          }
        }).then(res =>{
          if(res.data == null) 
            return alerta('Ups! Alguma coisa correu mal...', [{ text: 'Ok', handler: ()=>{window.location.reload()} }]);
          if(res.data["Code"]!=200) 
            window.location.href="/login";
          setInterval(()=>{
              axios({
                method: "get",
                url: API_URL+'/get_opcoes',
                headers:{},
              }).then(opcoes =>{
                if(opcoes.data == null) return alerta('Ups! Alguma coisa correu mal...', [{ text: 'Ok', handler: ()=>{window.location.reload()} }]);
                setListOpcoes2(opcoes.data);
              })
          },1000);
        })
    }
  });

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Página Inicial</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonRow>
          {listaOpcoes2.map(m=> <OpcaoComponent key={m.id} propOpcao={m}/>)}
        </IonRow>
      </IonContent>
    </IonPage>
  );
};

export default HomePage;
