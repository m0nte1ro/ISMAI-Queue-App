import { IonContent, 
    IonHeader, 
    IonPage, 
    IonTitle, 
    IonToolbar, 
    IonButton, 
    IonRow, 
    useIonAlert, 
    useIonViewWillEnter, 
    IonCardTitle, 
    IonCard, 
    IonCardHeader, 
    IonCardContent } from '@ionic/react';
import React, {useEffect, useState} from 'react';
import {useParams} from 'react-router';
import axios from 'axios';
import './Styles.css';

const API_URL = 'https://ismai-ticket-system.herokuapp.com/';


const TirarSenha: React.FC = () =>{

    const [alerta] = useIonAlert();
    const opcaoID = useParams<{id:string}>();
    const [senhaAtendimento, setSenhaAtendimento] = useState<''>();
    const [proximaSenha, setProximaSenha] = useState<''>();

    useIonViewWillEnter(()=>{ //Sistema de verificação muito fácil de enganar mas serve para enganar 99% das pessoas
        if(localStorage.getItem("user-token")==null){ //Se não tiver cookie ele nem tentar fazer mais nada
          window.location.href="/login";
        }else{
            axios({
              method:"POST",
              url: API_URL+'/verificar_token',
              headers:{},
              data:{
                token: localStorage.getItem("user-token")
              }
            }).then(res =>{
                if(res.data == null) 
                    return alerta('Ups! Alguma coisa correu mal...', [{ text: 'Ok', handler: ()=>{window.location.reload()} }]);
                if(res.data["Code"]!=200) 
                    window.location.href="/login";
            })
        }
      });

    React.useEffect(()=>{
        setInterval(()=>{
            axios.all([
                axios.post(API_URL + 'get_senha_em_atendimento',{
                    opcao_id: opcaoID.id
                }),
                axios.post(API_URL + 'get_ultima_senha',{
                    opcao_id: opcaoID.id
                })
            ]).then(axios.spread((senhaEmAtendimento, ultimaSenha)=>{
                if(senhaEmAtendimento.data==null || ultimaSenha == null) return alerta('Ups! Alguma coisa correu mal...', [{ text: 'Ok', handler: ()=>{window.location.reload()} }]);
                setSenhaAtendimento(senhaEmAtendimento.data["numsenha:"]);
                setProximaSenha(ultimaSenha.data["numsenha:"]);
            }))}
        ,1000);
    }, []);

    return(
        <>
        <IonPage>
            <IonHeader>
                <IonToolbar>
                <IonTitle>Senhas</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen>
                <div className='tirarSenhaWrapper'>
                    <IonCard className='tirarSenhaCard'>
                        <IonCardTitle>Senha em atendimento:</IonCardTitle>
                        <IonCardContent>{senhaAtendimento}</IonCardContent>
                    </IonCard>
                    <IonCard className='tirarSenhaCard'>
                        <IonCardTitle>Última senha tirada:</IonCardTitle>
                        <IonCardContent>{proximaSenha}</IonCardContent>
                    </IonCard>
                    <IonButton>Tirar Senha</IonButton>
                </div>
            </IonContent>
        </IonPage>
        
        </>
    );
};

export default TirarSenha;